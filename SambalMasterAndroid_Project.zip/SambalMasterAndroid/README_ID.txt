SAMBAL MASTER INDONESIA — PROYEK ANDROID

Isi:
- Game HTML offline di app/src/main/assets/index.html
- Aplikasi Android sederhana yang menampilkan game dalam WebView.
- Tidak memerlukan koneksi internet ketika dimainkan.

CARA MEMBUAT APK DENGAN ANDROID STUDIO:
1. Pasang Android Studio di komputer.
2. Ekstrak folder SambalMasterAndroid.
3. Android Studio > Open > pilih folder SambalMasterAndroid.
4. Tunggu Gradle Sync selesai. Jika diminta, pasang Android SDK Platform 35.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah selesai, klik "locate" pada notifikasi build. APK debug biasanya berada di:
   app/build/outputs/apk/debug/app-debug.apk
7. Pindahkan APK ke HP Android dan pasang. Jika diminta, izinkan instalasi dari sumber tersebut.

CATATAN:
- Ini adalah proyek sumber untuk menghasilkan APK; file APK yang sudah terkompilasi belum disertakan.
- Nama aplikasi: Sambal Master Indonesia
- Application ID: com.kocakfc.sambalmaster
- Versi: 1.0
